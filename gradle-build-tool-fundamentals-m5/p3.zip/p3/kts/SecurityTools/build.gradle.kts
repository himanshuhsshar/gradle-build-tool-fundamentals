val log4j_version: String by project
val jaxb_version: String by project
val junit_version: String by project

plugins {
  application
}

java {                                      
    sourceCompatibility = JavaVersion.VERSION_1_7
    targetCompatibility = JavaVersion.VERSION_1_7
}

repositories {
  jcenter()
}

dependencies {
  compileOnly("log4j:log4j:$log4j_version")
  implementation("javax.xml.bind:jaxb-api:$jaxb_version")
  testImplementation("junit:junit:$junit_version")
  testRuntimeOnly("log4j:log4j:$log4j_version")
}

application {
  mainClassName = "com.pluralsight.security.Hash"
}


/* val log4j_version: String by project
val jaxb_version: String by project
val junit_version: String by project

plugins {
  application
}

java {                                      
    sourceCompatibility = JavaVersion.VERSION_1_7
    targetCompatibility = JavaVersion.VERSION_1_7
}

repositories {
  jcenter()
}

dependencies {
  implementation("log4j:log4j:$log4j_version")
  implementation("javax.xml.bind:jaxb-api:$jaxb_version")
  testImplementation("junit:junit:$junit_version")
}

application {
  mainClassName = "com.pluralsight.security.Hash"
}*/



