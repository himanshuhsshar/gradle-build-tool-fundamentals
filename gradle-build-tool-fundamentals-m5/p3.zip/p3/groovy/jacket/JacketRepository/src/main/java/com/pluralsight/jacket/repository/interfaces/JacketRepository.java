package com.pluralsight.jacket.repository.interfaces;

import com.pluralsight.jacket.models.Entry;
import com.pluralsight.repository.Repository;


/**
 */
public interface JacketRepository extends Repository<Entry> {

}
