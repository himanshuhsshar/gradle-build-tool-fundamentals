# SpringWalkingSkeleton

This is a base project using an annotation driven Spring MVC 4 application that uses services and repositories (not Spring based). 

The code uses injection heavily  
