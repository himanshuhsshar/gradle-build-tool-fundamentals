package com.pluralsight.jacket.services;

/**
 * Created by kevin on 30/06/2015.
 */
public class AuthenticationService {

    String url;
    boolean isFavoutire;
    boolean isArchived;
}
